package ta_programacion3;

import java.util.Date;

public abstract class PersonalDeSalud extends Usuario {
    
    protected int codigoMedico;
    
    public PersonalDeSalud(int idUsuario, Date fechaRegistro, String contraseña,
            String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad,
            String nombre, String apellidoPaterno, String apellidoMaterno,
            String genero, Date fechaNacimiento, Estado estado, int codigoMedico) {
    
        super(idUsuario, fechaRegistro, contraseña, correoElectronico,
                nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno,
                apellidoMaterno, genero, fechaNacimiento, estado);
        this.codigoMedico = codigoMedico;
    }

    public int getCodigoMedico() {
        return codigoMedico;
    }

    public void setCodigoMedico(int codigoMedico) {
        this.codigoMedico = codigoMedico;
    }
    
    
    public void CrearAtencionMedica(AtencionMedica atencion){}
    public void ModificarAtencionMedica(AtencionMedica atencion){}
    public void EliminarAtencionMedica(int idAtencion) {}
    public void ModificarDatosMedicosAlumno(Alumno a) {}
    
}
