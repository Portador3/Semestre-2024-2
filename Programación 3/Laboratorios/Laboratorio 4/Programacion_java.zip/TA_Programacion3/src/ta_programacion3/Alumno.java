package ta_programacion3;
import java.util.ArrayList; 
import java.util.Date;

public class Alumno extends Persona {
    private int codigoAlumno; 
    private Aula aula;
    private ArrayList<ContactoEmergencia> contactos;
    private ArrayList<String> alergias; 
    private ArrayList<String> observacionesMedicas; 
    private String grupoSanguineo; 
    private int NSA_titular; 
    private SituacionFAP situacionFAP;
    private String seguro; 

    public Alumno(int codigoAlumno, Aula aula, ArrayList<ContactoEmergencia> contactos,
            ArrayList<String> alergias, ArrayList<String> observacionesMedicas,
            String grupoSanguineo, int NSA_titular, SituacionFAP situacionFAP, 
            String seguro, String nroDocumento, String tipoDocumentoIdentidad, 
            String nombre, String apellidoPaterno, String apellidoMaterno, 
            String genero, Date fechaNacimiento, Estado estado) {
        super(nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno, genero, fechaNacimiento, estado);
        this.codigoAlumno = codigoAlumno;
        this.aula = aula;
        this.contactos = contactos;
        this.alergias = alergias;
        this.observacionesMedicas = observacionesMedicas;
        this.grupoSanguineo = grupoSanguineo;
        this.NSA_titular = NSA_titular;
        this.situacionFAP = situacionFAP;
        this.seguro = seguro;
    }

    public int getCodigoAlumno() {
        return codigoAlumno;
    }

    public void setCodigoAlumno(int codigoAlumno) {
        this.codigoAlumno = codigoAlumno;
    }

    public Aula getAula() {
        return aula;
    }

    public void setAula(Aula aula) {
        this.aula = aula;
    }

    public ArrayList<ContactoEmergencia> getContactos() {
        return contactos;
    }

    public void setContacto(ArrayList<ContactoEmergencia> contactos) {
        this.contactos = contactos;
    }

    public ArrayList<String> getAlergias() {
        return alergias;
    }

    public void setAlergias(ArrayList<String> alergias) {
        this.alergias = alergias;
    }

    public ArrayList<String> getObservacionesMedicas() {
        return observacionesMedicas;
    }

    public void setObservacionesMedicas(ArrayList<String> observacionesMedicas) {
        this.observacionesMedicas = observacionesMedicas;
    }

    public String getGrupoSanguineo() {
        return grupoSanguineo;
    }

    public void setGrupoSanguineo(String grupoSanguineo) {
        this.grupoSanguineo = grupoSanguineo;
    }

    public int getNSA_titular() {
        return NSA_titular;
    }

    public void setNSA_titular(int NSA_titular) {
        this.NSA_titular = NSA_titular;
    }

    public SituacionFAP getSituacionFAP() {
        return situacionFAP;
    }

    public String getSeguro() {
        return seguro;
    }

    public void setSeguro(String seguro) {
        this.seguro = seguro;
    }
    
    @Override
    public String ConsultarDatos() {
        String str = super.ConsultarDatos();
        return str;
    }
    
    public String HistorialMedico() {
        String str = "";
        return str;
    }
    
    public void AgregarObservacionMedica(String obs) {
        this.observacionesMedicas.add(obs);
    }

}
