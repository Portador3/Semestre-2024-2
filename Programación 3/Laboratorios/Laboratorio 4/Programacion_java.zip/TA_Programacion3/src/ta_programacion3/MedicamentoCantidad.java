package ta_programacion3;

public class MedicamentoCantidad {
    
    private int cantidad;  
    private Medicamento medicamento;
    
    public MedicamentoCantidad(Medicamento medicamento, int cantidad) {
        this.cantidad = cantidad;
        this.medicamento = medicamento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(Medicamento medicamento) {
        this.medicamento = medicamento;
    }
    
    
    
}
