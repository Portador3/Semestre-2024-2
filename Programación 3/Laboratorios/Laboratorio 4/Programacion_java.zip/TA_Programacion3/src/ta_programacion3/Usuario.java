package ta_programacion3;

import java.util.Date; 

public abstract class Usuario extends Persona {
    protected int idUsuario; 
    protected Date fechaRegistro; 
    protected String contraseña; 
    protected String correoElectronico; 

    public Usuario(int idUsuario, Date fechaRegistro,
            String contraseña, String correoElectronico, String nroDocumento,
            String tipoDocumentoIdentidad, String nombre, String apellidoPaterno,
            String apellidoMaterno, String genero, Date fechaNacimiento, Estado estado) {
        super(nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno,
                apellidoMaterno, genero, fechaNacimiento, estado);
        this.idUsuario = idUsuario;
        this.fechaRegistro = fechaRegistro;
        this.contraseña = contraseña;
        this.correoElectronico = correoElectronico;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }
    
    public void ModificarDatos(Usuario u){}
    
}
