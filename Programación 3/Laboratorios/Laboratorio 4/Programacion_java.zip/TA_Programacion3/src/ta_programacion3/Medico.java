package ta_programacion3;
import java.util.Date; 

public class Medico extends PersonalDeSalud implements GestionarPracticantes{
    private String CMP; 
    private String especialidad; 

    public Medico(String CMP, String especialidad, int idUsuario,
            Date fechaRegistro, String contraseña, String correoElectronico,
            String nroDocumento, String tipoDocumentoIdentidad, String nombre,
            String apellidoPaterno, String apellidoMaterno, String genero,
            Date fechaNacimiento, Estado estado, int codigoMedico) {
        super(idUsuario, fechaRegistro, contraseña, correoElectronico,
                nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno,
                apellidoMaterno, genero, fechaNacimiento, estado, codigoMedico);
        this.CMP = CMP;
        this.especialidad = especialidad;
    }
    
    @Override
    public void RegistrarPracticante(Practicante p){
        
    }
    
    @Override
    public void EliminarPracticante(int codigoPracticante){
        
    }
    
    @Override
    public void ModificarPracticante(Practicante p){
        
    }
    
    @Override
    public void ModificarDatos(Usuario u){
        
    }
    
    @Override
    public void CrearAtencionMedica(AtencionMedica atencion){
        
    }
    
    @Override
    public void ModificarAtencionMedica(AtencionMedica atencion){
        
    }
    
    @Override
    public void EliminarAtencionMedica(int idAtencion){
        
    }
    
    @Override
    public void ModificarDatosMedicosAlumno(Alumno alumno){
        
    }
    
    public void SolicitarMedicamentos(Pedido pedido){
        
    }

    public String getCMP() {
        return CMP;
    }

    public void setCMP(String CMP) {
        this.CMP = CMP;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}
