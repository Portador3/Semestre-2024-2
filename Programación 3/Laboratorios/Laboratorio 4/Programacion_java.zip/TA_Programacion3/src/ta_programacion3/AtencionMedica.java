package ta_programacion3;

import java.util.Date; 
import java.time.LocalTime; 
import java.util.ArrayList;

public class AtencionMedica implements InfoProvider {
    private static int correlativo = 1;
    private int idAtencionMedica;
    private Date fechaAtencion; 
    private LocalTime horaAtencion; 
    private String motivoAtencion; 
    private String comentariosAtencion; 
    private Boolean derivadoHospital; 
    private PersonalDeSalud encargadoDeAtencion;
    private Alumno paciente;
    private ArrayList<MedicamentoCantidad> medicamentos;
    
    public AtencionMedica(Date fechaAtencion, LocalTime horaAtencion,
            String motivoAtencion, String comentariosAtencion, Boolean derivadoHospital,
            PersonalDeSalud encargadoDeAtencion, Alumno paciente) {
        this.idAtencionMedica = correlativo++;
        this.fechaAtencion = fechaAtencion;
        this.horaAtencion = horaAtencion;
        this.motivoAtencion = motivoAtencion;
        this.comentariosAtencion = comentariosAtencion;
        this.derivadoHospital = derivadoHospital;
        this.encargadoDeAtencion = encargadoDeAtencion;
        this.paciente = paciente;
        this.medicamentos = new ArrayList<>();
    }

    public static int getCorrelativo() {
        return correlativo;
    }

    public static void setCorrelativo(int correlativo) {
        AtencionMedica.correlativo = correlativo;
    }
    
    public int getIdAtencionMedica() {
        return idAtencionMedica;
    }
    
    public Date getFechaAtencion() {
        return fechaAtencion;
    }

    public void setFechaAtencion(Date fechaAtencion) {
        this.fechaAtencion = fechaAtencion;
    }

    public LocalTime getHoraAtencion() {
        return horaAtencion;
    }

    public void setHoraAtencion(LocalTime horaAtencion) {
        this.horaAtencion = horaAtencion;
    }

    public String getMotivoAtencion() {
        return motivoAtencion;
    }

    public void setMotivoAtencion(String motivoAtencion) {
        this.motivoAtencion = motivoAtencion;
    }

    public String getComentariosAtencion() {
        return comentariosAtencion;
    }

    public void setComentariosAtencion(String comentariosAtencion) {
        this.comentariosAtencion = comentariosAtencion;
    }

    public Boolean getDerivadoHospital() {
        return derivadoHospital;
    }

    public void setDerivadoHospital(Boolean derivadoHospital) {
        this.derivadoHospital = derivadoHospital;
    }

    public PersonalDeSalud getEncargadoDeAtencion() {
        return encargadoDeAtencion;
    }

    public void setEncargadoDeAtencion(PersonalDeSalud encargadoDeAtencion) {
        this.encargadoDeAtencion = encargadoDeAtencion;
    }

    public Alumno getPaciente() {
        return paciente;
    }

    public void setMedicamentos(ArrayList<MedicamentoCantidad> medicamentos) {
        this.medicamentos = medicamentos;
    }
    
    public void agregarMedicamento(MedicamentoCantidad m){
        this.medicamentos.add(m);
    }

    @Override
    public String ConsultarDatos() {
        String str = "";
        return str;
    }
    
}
