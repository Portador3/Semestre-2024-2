package ta_programacion3;

public enum SituacionFAP {
    FAP, NO_FAP; 
}
    