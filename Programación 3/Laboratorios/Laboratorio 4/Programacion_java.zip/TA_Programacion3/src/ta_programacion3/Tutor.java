package ta_programacion3;

import java.util.Date;

public class Tutor extends Persona {
    private int codigoProfesor; 
    private String celular; 
    
    public Tutor(int codigoProfesor, String celular, String nroDocumento, 
            String tipoDocumentoIdentidad, String nombre, String apellidoPaterno,
            String apellidoMaterno, String genero, Date fechaNacimiento, Estado estado) {
        super(nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno,
                genero, fechaNacimiento, estado);
        this.codigoProfesor = codigoProfesor;
        this.celular = celular;
    }

    public int getCodigoProfesor() {
        return codigoProfesor;
    }

    public void setCodigoProfesor(int codigoProfesor) {
        this.codigoProfesor = codigoProfesor;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    
}
