package ta_programacion3;
import java.util.Date;

public abstract class Persona implements InfoProvider {
    protected String nroDocumento;
    protected String tipoDocumentoIdentidad;
    protected String nombre; 
    protected String apellidoPaterno; 
    protected String apellidoMaterno; 
    protected String sexo;
    protected Date fechaNacimiento;
    protected Estado estado;

    public Persona(String nroDocumento, String tipoDocumentoIdentidad, String nombre,
            String apellidoPaterno, String apellidoMaterno, String genero,
            Date fechaNacimiento, Estado estado) {
        this.nroDocumento = nroDocumento;
        this.tipoDocumentoIdentidad = tipoDocumentoIdentidad;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.sexo = genero;
        this.fechaNacimiento = fechaNacimiento;
        this.estado = estado;
    }

    public String getNroDocumento() {
        return nroDocumento;
    }

    public void setNroDocumento(String nroDocumento) {
        this.nroDocumento = nroDocumento;
    }

    public String getTipoDocumentoIdentidad() {
        return tipoDocumentoIdentidad;
    }

    public void setTipoDocumentoIdentidad(String tipoDocumentoIdentidad) {
        this.tipoDocumentoIdentidad = tipoDocumentoIdentidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Estado getEstado() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
    
    @Override
    public String ConsultarDatos() {
        String str = "";
        return str;
    }
    
}
