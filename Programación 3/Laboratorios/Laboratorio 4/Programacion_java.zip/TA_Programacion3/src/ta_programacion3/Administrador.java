package ta_programacion3;

import java.util.Date;

public class Administrador extends Usuario implements GestionarPracticantes{
    private int idAdmin; 

    public Administrador(int idUsuario, Date fechaRegistro, String contraseña,
            String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad,
            String nombre, String apellidoPaterno, String apellidoMaterno,
            String genero, Date fechaNacimiento, Estado estado, int idAdmin) {
        super(idUsuario, fechaRegistro, contraseña, correoElectronico,
                nroDocumento, tipoDocumentoIdentidad, nombre,
                apellidoPaterno, apellidoMaterno, genero, fechaNacimiento, estado);
        this.idAdmin = idAdmin;
    }
    
    @Override
    public void RegistrarPracticante(Practicante p){
        
    }
    
    @Override
    public void EliminarPracticante(int codigoPracticante){
        
    }
    
    @Override
    public void ModificarPracticante(Practicante p){
        
    }
       
    public void RegistrarDoctor(Medico m){
        
    }
    
    public void EliminarDoctor(int CMP){
        
    }
    
    public void ModificarDoctor(Medico m){
        
    }
    
    @Override
    public void ModificarDatos(Usuario u){
        
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }
}
