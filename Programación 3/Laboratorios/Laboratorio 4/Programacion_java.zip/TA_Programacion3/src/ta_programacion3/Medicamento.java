package ta_programacion3;

public class Medicamento implements InfoProvider {
    
    private String codigo; 
    private String nombre; 
    private int stock; 
    private String marca;
    private String dosis;
    private ViaDeAdministracion viaDeAdministacion; 

    public Medicamento(String codigo, String nombre, int stock, String marca, String dosis, ViaDeAdministracion viaDeAdministacion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.stock = stock;
        this.marca = marca;
        this.dosis = dosis;
        this.viaDeAdministacion = viaDeAdministacion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public ViaDeAdministracion getViaDeAdministacion() {
        return viaDeAdministacion;
    }

    public void setViaDeAdministacion(ViaDeAdministracion viaDeAdministacion) {
        this.viaDeAdministacion = viaDeAdministacion;
    }

    @Override
    public String ConsultarDatos() {
        String str = "";
        return str;
    }
    
    
}
