package ta_programacion3;

/**
 *
 * @author user
 */
public enum Estado {
    ACTIVO, INVACTIVO
}
