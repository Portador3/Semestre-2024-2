package ta_programacion3;

import java.util.Date;

public class Practicante extends PersonalDeSalud {

    public Practicante(int idUsuario, Date fechaRegistro, String contraseña,
            String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad,
            String nombre, String apellidoPaterno, String apellidoMaterno, String genero,
            Date fechaNacimiento, Estado estado, int codigoMedico) {
        super(idUsuario, fechaRegistro, contraseña, correoElectronico, nroDocumento,
                tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno,
                genero, fechaNacimiento, estado, codigoMedico);
    
    }
    
    @Override
    public void ModificarDatos(Usuario u){
        
    }
    
    @Override
    public void CrearAtencionMedica(AtencionMedica atencion){
        
    }
    
    @Override
    public void ModificarAtencionMedica(AtencionMedica atencion){
        
    }
    
    @Override
    public void EliminarAtencionMedica(int idAtencion){
        
    }
    
    @Override
    public void ModificarDatosMedicosAlumno(Alumno a){
        
    }
    
}
