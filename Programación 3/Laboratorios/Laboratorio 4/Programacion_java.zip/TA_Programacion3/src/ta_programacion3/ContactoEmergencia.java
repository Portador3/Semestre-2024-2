package ta_programacion3;

public class ContactoEmergencia implements InfoProvider {
    private String nombre; 
    private String apellido; 
    private String parentezco; 
    private String celular; 
    private String correo;
    public ContactoEmergencia(String nombre, String apellido, String parentezco, String celular, String correo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.parentezco = parentezco;
        this.celular = celular;
        this.correo = correo;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getParentezco() {
        return parentezco;
    }

    public void setParentezco(String parentezco) {
        this.parentezco = parentezco;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    @Override
    public String ConsultarDatos() {
        String str = "";
        return str;
    }
    
    
}
