package ta_programacion3;


public enum ViaDeAdministracion {
    ORAL, INYECTABLE
}
