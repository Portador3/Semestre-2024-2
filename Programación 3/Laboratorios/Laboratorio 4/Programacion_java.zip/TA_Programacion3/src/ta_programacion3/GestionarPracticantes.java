package ta_programacion3;


public interface GestionarPracticantes {
    public void RegistrarPracticante(Practicante p);
    public void EliminarPracticante(int codigoPracticante);
    public void ModificarPracticante(Practicante P);
}
