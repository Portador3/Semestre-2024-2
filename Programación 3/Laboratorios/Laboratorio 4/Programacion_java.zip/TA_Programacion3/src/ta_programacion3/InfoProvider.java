package ta_programacion3;


public interface InfoProvider {
    String ConsultarDatos();
}
