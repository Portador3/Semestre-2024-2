package pe.edu.pucp.eventmastersoft.logistica.dao;
public interface LocalDAO {
    
}
