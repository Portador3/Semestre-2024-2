interface IDataProvider{
	String devolverCabecera();
}