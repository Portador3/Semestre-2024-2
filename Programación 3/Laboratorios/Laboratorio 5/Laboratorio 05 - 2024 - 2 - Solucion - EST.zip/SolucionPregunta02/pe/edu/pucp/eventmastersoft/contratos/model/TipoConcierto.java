package pe.edu.pucp.eventmastersoft.contratos.model;
public enum TipoConcierto{
	DE_SALA, ACUSTICO, RECITAL, SINFONICO
}