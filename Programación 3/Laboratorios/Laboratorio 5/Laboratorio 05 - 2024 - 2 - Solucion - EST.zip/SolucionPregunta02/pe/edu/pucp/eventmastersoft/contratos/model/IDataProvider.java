package pe.edu.pucp.eventmastersoft.contratos.model;
public interface IDataProvider{
	String devolverCabecera();
}