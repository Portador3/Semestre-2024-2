package pe.edu.pucp.eventmastersoft.logistica.model;
public enum TipoLocal{
	TEATRO, AUDITORIO, ANFITEATRO, ESTADIO
}