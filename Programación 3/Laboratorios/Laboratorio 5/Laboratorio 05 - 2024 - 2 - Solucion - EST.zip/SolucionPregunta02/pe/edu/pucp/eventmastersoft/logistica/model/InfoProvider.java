package pe.edu.pucp.eventmastersoft.logistica.model;
public interface InfoProvider{
	String devolverDatos();
}