package pe.edu.pucp.eventmastersoft.logistica.dao;

import pe.edu.pucp.eventmastersoft.logistica.model.Local;

public interface LocalDAO {
    int insertar(Local local);
}
