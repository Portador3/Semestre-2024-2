package ta_programacion3;

public class ContactoEmergencia {
    private String nombre; 
    private String apellido; 
    private String parentezco; 
    private String celular; 

    public ContactoEmergencia(String nombre, String apellido, String parentezco, String celular) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.parentezco = parentezco;
        this.celular = celular;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getParentezco() {
        return parentezco;
    }

    public void setParentezco(String parentezco) {
        this.parentezco = parentezco;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
    
    
}
