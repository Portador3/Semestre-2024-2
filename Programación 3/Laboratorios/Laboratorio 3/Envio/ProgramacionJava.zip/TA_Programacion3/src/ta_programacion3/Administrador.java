package ta_programacion3;

import java.util.Date;

public class Administrador extends Usuario implements GestionarPracticantes{
    private int idAdmin; 

    public Administrador(int idUsuario, Date fechaRegistro, Boolean activo, String contraseña, String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad, String nombre, String apellidoPaterno, String apellidoMaterno, String genero, Date fechaNacimiento) {
        super(idUsuario, fechaRegistro, activo, contraseña, correoElectronico, nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno, genero, fechaNacimiento);
    }
    
    @Override
    public void RegistrarPracticante(Usuario p){
        
    }
    
    @Override
    public void EliminarPracticante(int codigoPracticante){
        
    }
    
    @Override
    public void ModificarPracticante(int codigoPracticante){
        
    }
       
    public void RegistrarDoctor(Usuario d){
        
    }
    
    public void EliminarDoctor(int codigoDoctor){
        
    }
    
    public void ModificarDoctor(int codigoDoctor){
        
    }
    @Override
    public void ModificarDatos(){
        
    }

    public int getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(int idAdmin) {
        this.idAdmin = idAdmin;
    }
}
