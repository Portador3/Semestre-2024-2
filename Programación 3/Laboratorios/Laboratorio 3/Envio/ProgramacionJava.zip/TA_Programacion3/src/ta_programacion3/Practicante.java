package ta_programacion3;

import java.util.Date;

public class Practicante extends PersonalDeSalud {
    private int codigoPracticante; 

    public Practicante(int idUsuario, Date fechaRegistro, Boolean activo, String contraseña, String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad, String nombre, String apellidoPaterno, String apellidoMaterno, String genero, Date fechaNacimiento) {
        super(idUsuario, fechaRegistro, activo, contraseña, correoElectronico, nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno, genero, fechaNacimiento);
    }
    
    @Override
    public void ModificarDatos(){
        
    }
    
    @Override
    public void CrearAtencionMedica(){
        
    }
    
    @Override
    public void ModificarAtencionMedica(){
        
    }
    
    @Override
    public void EliminarAtencionMedica(){
        
    }
    
    @Override
    public void ModificarDatosMedicosAlumno(){
        
    }

    public int getCodigoPracticante() {
        return codigoPracticante;
    }

    public void setCodigoPracticante(int codigoPracticante) {
        this.codigoPracticante = codigoPracticante;
    }
    
    
}
