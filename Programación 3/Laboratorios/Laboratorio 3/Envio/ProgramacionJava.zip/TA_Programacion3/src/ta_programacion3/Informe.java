package ta_programacion3;

import java.util.Date; 
public class Informe {
    private int idInforme; 
    private String contenido; 
    private Date fecha; 
    private Medico medicoSolicitante;
    private AtencionMedica atencionMedica;
    
    public Informe(int idInforme, String contenido, Date fecha, Medico medicoSolicitante, AtencionMedica atencionMedica) {
        this.idInforme = idInforme;
        this.contenido = contenido;
        this.fecha = fecha;
        this.medicoSolicitante = medicoSolicitante;
        this.atencionMedica = atencionMedica;
    }
    
    public String imprimirInforme(){
        String cadena = "informe";
        return cadena;
    }

    public int getIdInforme() {
        return idInforme;
    }

    public void setIdInforme(int idInforme) {
        this.idInforme = idInforme;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Medico getMedicoSolicitante() {
        return medicoSolicitante;
    }

    public void setMedicoSolicitante(Medico medicoSolicitante) {
        this.medicoSolicitante = medicoSolicitante;
    }

    public AtencionMedica getAtencionMedica() {
        return atencionMedica;
    }

    public void setAtencionMedica(AtencionMedica atencionMedica) {
        this.atencionMedica = atencionMedica;
    }
    
    
    
}
