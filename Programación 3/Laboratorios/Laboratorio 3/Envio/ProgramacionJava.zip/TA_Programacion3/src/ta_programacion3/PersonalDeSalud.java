package ta_programacion3;

import java.util.Date;

public abstract class PersonalDeSalud extends Usuario {
    
    public PersonalDeSalud(int idUsuario, Date fechaRegistro, Boolean activo, String contraseña, String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad, String nombre, String apellidoPaterno, String apellidoMaterno, String genero, Date fechaNacimiento) {
        super(idUsuario, fechaRegistro, activo, contraseña, correoElectronico, nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno, genero, fechaNacimiento);
    }
    
    public void CrearAtencionMedica() {}
    public void ModificarAtencionMedica() {}
    public void EliminarAtencionMedica() {}
    public void ModificarDatosMedicosAlumno() {}
    
}
