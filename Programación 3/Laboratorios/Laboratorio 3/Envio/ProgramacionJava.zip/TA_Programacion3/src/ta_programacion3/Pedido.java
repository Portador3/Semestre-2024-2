package ta_programacion3;

import java.util.Date; 
import java.util.ArrayList; 

public class Pedido {
    private String codigo; 
    private ArrayList<MedicamentoCantidad> medicamentos;
    private Date fecha; 

    public Pedido(String codigo,ArrayList<MedicamentoCantidad> medicamentos, Date fecha) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.medicamentos = medicamentos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public ArrayList<MedicamentoCantidad> getMedicamentos() {
        return medicamentos;
    }

    public void setMedicamentos(ArrayList<MedicamentoCantidad> medicamentos) {
        this.medicamentos = medicamentos;
    }
    
    
}
