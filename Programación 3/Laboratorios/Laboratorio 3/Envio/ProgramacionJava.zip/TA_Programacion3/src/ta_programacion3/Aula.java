package ta_programacion3;

public class Aula {
    private String nivel; 
    private String grado; 
    private char seccion; 
    private Tutor tutor;
    
    public Aula(String nivel, String grado, char seccion, Tutor tutor) {
        this.nivel = nivel;
        this.grado = grado;
        this.seccion = seccion;
        this.tutor = tutor;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public char getSeccion() {
        return seccion;
    }

    public void setSeccion(char seccion) {
        this.seccion = seccion;
    }

    public Tutor getTutor() {
        return tutor;
    }

    public void setTutor(Tutor tutor) {
        this.tutor = tutor;
    }
    
}
