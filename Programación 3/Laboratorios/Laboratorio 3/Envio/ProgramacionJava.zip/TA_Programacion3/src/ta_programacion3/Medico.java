package ta_programacion3;
import java.util.Date; 

public class Medico extends PersonalDeSalud implements GestionarPracticantes{
    private int codigoMedico; 
    private String CMP; 
    private String especialidad; 

    public Medico(int codigoMedico, String CMP, String especialidad, int idUsuario, Date fechaRegistro, Boolean activo, String contraseña, String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad, String nombre, String apellidoPaterno, String apellidoMaterno, String genero, Date fechaNacimiento) {
        super(idUsuario, fechaRegistro, activo, contraseña, correoElectronico, nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno, genero, fechaNacimiento);
        this.codigoMedico = codigoMedico;
        this.CMP = CMP;
        this.especialidad = especialidad;
    }
    
    @Override
    public void RegistrarPracticante(Usuario p){
        
    }
    
    @Override
    public void EliminarPracticante(int codigoPracticante){
        
    }
    
    @Override
    public void ModificarPracticante(int codigoPracticante){
        
    }
    
    @Override
    public void ModificarDatos(){
        
    }
    
    @Override
    public void CrearAtencionMedica(){
        
    }
    
    @Override
    public void ModificarAtencionMedica(){
        
    }
    
    @Override
    public void EliminarAtencionMedica(){
        
    }
    
    @Override
    public void ModificarDatosMedicosAlumno(){
        
    }
    
    public void SolicitarMedicamentos(Pedido pedido){
        
    }

    public int getCodigoMedico() {
        return codigoMedico;
    }

    public void setCodigoMedico(int codigoMedico) {
        this.codigoMedico = codigoMedico;
    }

    public String getCMP() {
        return CMP;
    }

    public void setCMP(String CMP) {
        this.CMP = CMP;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
}
