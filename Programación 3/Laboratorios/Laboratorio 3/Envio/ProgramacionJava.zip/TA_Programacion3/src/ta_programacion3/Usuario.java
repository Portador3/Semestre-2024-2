package ta_programacion3;

import java.util.Date; 

public abstract class Usuario extends Persona {
    protected int idUsuario; 
    protected Date fechaRegistro; 
    protected Boolean activo; 
    protected String contraseña; 
    protected String correoElectronico; 

    public Usuario(int idUsuario, Date fechaRegistro, Boolean activo, String contraseña, String correoElectronico, String nroDocumento, String tipoDocumentoIdentidad, String nombre, String apellidoPaterno, String apellidoMaterno, String genero, Date fechaNacimiento) {
        super(nroDocumento, tipoDocumentoIdentidad, nombre, apellidoPaterno, apellidoMaterno, genero, fechaNacimiento);
        this.idUsuario = idUsuario;
        this.fechaRegistro = fechaRegistro;
        this.activo = activo;
        this.contraseña = contraseña;
        this.correoElectronico = correoElectronico;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }
    
    public void ModificarDatos(){}
    
}
